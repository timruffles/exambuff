<?php $this->load->helper('url'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>exambuff - Polish up your skills. Polish off your exams.</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
<link type="text/css" rel="stylesheet" href="<?=$site_base?>css/style.css" >
<script type="text/javascript" src="<?=$site_base?>js/jquerymin.js"></script>
<script type="text/javascript" src="<?=$site_base?>js/highlight.js"></script>
<script type="text/javascript" src="<?=$site_base?>js/uploader.js"></script>
<script type="text/javascript" src="<?=$site_base?>js/jquery.autocomplete.js"></script>
<?php
if(@$extraScripts):
foreach($extraScripts as $script) : ?>
<script type="text/javascript" src="<?=$site_base?>js/<?=$script?>.js"></script>
<?php
endforeach;
endif;?>
<script type="text/javascript" >var base_url = '<?=base_url(); ?>index.php/'</script>
</head>