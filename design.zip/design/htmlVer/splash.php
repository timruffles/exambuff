

		<div id="splashbox">

			<h2 class="slogan">Polish up your skills. Polish off your exams.</h2>

			<div class="contents">
				<div class="chunk" id="sub-write">
					<h3>Write</h3>
					<p></p>
				</div>
				<div class="chunk" id="sub-read">
					<h3 >Read</h3>
					<p></p>
				</div>
				<div class="chunk" id="sub-succeed">
					<h3 >Succeed</h3>
					<p></p>
				</div>
			</div>
		</div>