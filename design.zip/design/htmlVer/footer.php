</div><?php //end #page here ?>
<div class="footer">
		<ul class="seo">
			<?php
			$i=0;
			foreach($site_pages as $page => $link) :
				$i++;
				if($i==1):
					$spacer = '';
				else:
					$spacer = '&nbsp;::&nbsp;';
				endif;
			?>
			<li><?=$spacer?><a class="menuitem" href="<?=$link?>"><?=$page?></a></li>
			<?php endforeach; ?>
		</ul>
		<ul class="copyright">exambuff limited, copyright 2008</ul>
	</div>
</div>
</body>
</html>