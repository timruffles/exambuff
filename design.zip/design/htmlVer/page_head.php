</head>
<body id="<?php if(@$bodyId) echo 'body-'.$bodyId ?>">
<div id="main">
<div id="header">
<h1>Exambuff</h1>
<div class="tabs">
<ul>
<?php
$i=0;
foreach($site_pages as $page => $link) :
	$i++;
	$id = 'id='.$page.'-tab';
?>
<li><a class="menuitem" <?=$id?> href="<?=$link?>"><?=$page?></a></li>
<?php endforeach; ?>
</ul>
</div>
</div>
<div id="page">