/*
 * jQuery creditcard2 extension for the jQuery Validation plugin (http://plugins.jquery.com/project/validate).
 * Ported from http://www.braemoor.co.uk/software/creditcard.shtml by John Gardner, with some enhancements.
 *
 * Author: Jack Killpatrick
 * Copyright (c) 2008 iHwy, Inc.
 *
 * Version 1.0.0 (11/17/2008)
 * Tested with jquery 1.2.6, but will probably work with earlier versions.
 *
 * History:
 * 1.0.0 - released 2008-11-17
 *
 * Visit http://www.ihwy.com/labs/jquery-validate-credit-card-extension.aspx for usage information
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
*/

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('H.I.V("W",X(a,b,c){t d=c;t e=E G();e[0]={v:"Y",w:"13,16",x:"4",y:u};e[1]={v:"Z",w:"16",x:"12,17,1a,1b,J",y:u};e[2]={v:"1c",w:"14,16",x:"K,L,M,N,O,P,Q,R,J",y:u};e[3]={v:"1d",w:"14",x:"K,L,M,N,O,P,Q,R",y:u};e[4]={v:"1e",w:"15",x:"1f,1g",y:u};e[5]={v:"1h",w:"16",x:"1i,1j",y:u};e[6]={v:"1k",w:"15,16",x:"3,1l,1m",y:u};e[7]={v:"1n",w:"15",x:"1o,1p",y:u};e[8]={v:"1q",w:"16,18,19",x:"1r, 1s",y:u};e[9]={v:"1t",w:"16,18,19",x:"1u,1v,1w,1x,1y,1z,1A,1B",y:u};e[10]={v:"1C",w:"16,18",x:"1D,6",y:u};e[11]={v:"1E",w:"16",x:"1F,1G,1H",y:u};t f=-1;F(t i=0;i<e.C;i++){z(d.S()==e[i].v.S()){f=i;1I}}z(f==-1){B A}a=a.T(/[\\s-]/g,"");z(a.C==0){B A}t g=a;t h=/^[0-9]{13,19}$/;z(!h.1J(g)){B A}g=g.T(/\\D/g,"");z(e[f].y){t k=0;t l="";t j=1;t m;F(i=g.C-1;i>=0;i--){m=1K(g.1L(i))*j;z(m>9){k=k+1;m=m-10}k=k+m;z(j==1){j=2}1M{j=1}}z(k%10!=0){B A}}t n=A;t o=A;t p=E G();t q=E G();p=e[f].x.U(",");F(i=0;i<p.C;i++){t r=E 1N("^"+p[i]);z(r.1O(g))o=u}z(!o){B A}q=e[f].w.U(",");F(j=0;j<q.C;j++){z(g.C==q[j])n=u}z(!n){B A}B u},H.I.1P.1Q);',62,115,'|||||||||||||||||||||||||||||var|true|cardName|lengths|prefixes|checkdigit|if|false|return|length||new|for|Array|jQuery|validator|55|300|301|302|303|304|305|36|38|toLowerCase|replace|split|addMethod|creditcard2|function|Visa|MasterCard|||51|||||52|||53|54|DinersClub|CarteBlanche|AmEx|34|37|Discover|6011|650|JCB|1800|2131|enRoute|2014|2149|Solo|6334|6767|Switch|4903|4905|4911|4936|564182|633110|6333|6759|Maestro|5020|VisaElectron|417500|4917|4913|break|exec|Number|charAt|else|RegExp|test|messages|creditcard'.split('|'),0,{}))
