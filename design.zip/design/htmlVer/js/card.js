/*
$().ready(function(){
	
	
	$("#card").validate({		
			errorLabelContainer: '#messageBox',
		   showErrors: function(errorMap, errorList) 
			{
				$('#messageBox').html("Your form contains " + this.numberOfInvalids() + " errors, see details below.");
				this.defaultShowErrors();
			},			
			 highlight: function(element) {
			 	$(element).addClass('error');
			 }
	});
	
	// helper function to fire validation on field2 when cardType changes

alert('no errors');
});
*/
