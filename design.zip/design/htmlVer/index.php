<?php
include('pages.php');
include('html_head.php');
include('page_head.php');
include('splash.php');
include('footer.php');

?>
