<?php
$site_page['faq'] = 'faq.php';
$site_page['jobs'] = 'jobs.php';
$site_page['about us'] = 'about-us.php';
$site_page['home'] = 'index.php';
?>