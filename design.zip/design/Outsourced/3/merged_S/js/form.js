function change(flag)
{
	switch(flag)
	{
	case 0:
		document.getElementById("fileTxt1").value = document.getElementById("file1").value;
		break;
	case 1:
		document.getElementById("file1").value = document.getElementById("fileTxt1").value;
		break;
	}
}

function hover(obj) 
{
	obj.className = "button_hover";
}

function unhover(obj) 
{
	obj.className = "button";
}

function browseFile(id)
{
	var oFile = document.getElementById(id);
	//window.fireEvent();
	oFile.fireEvent("onclick");
}